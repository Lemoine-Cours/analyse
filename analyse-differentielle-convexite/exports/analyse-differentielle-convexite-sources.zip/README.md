# Analyse différentielle et convexité

50 diapositives de socle, 4 compléments, couverture et clôture : 56 pages. Coordonnées et vecteurs explicites en colonnes, notations du cours et charte IMT Atlantique. Les figures sont en TikZ et restent éditables ; les notes donnent des repères de lecture ; les résultats sont admis sans preuve. Les compléments hors socle ne sont pas inclus.

Extraire tout le ZIP puis compiler avec `./build.ps1` sous PowerShell ou `bash build.sh` sous Linux/macOS. Le résultat est `cours.pdf`. LuaLaTeX, Montserrat, STIX Two Math et les dépendances du thème sont nécessaires. Le thème et ses fonds sont inclus : aucun sous-module à récupérer. Trois passages ; les débordements et caractères manquants bloquent l’export.

Contrôles avec Python standard : `python verification/verifier_calculs.py`, `python verification/verifier_dependances.py` et `python verification/verifier_colonnes.py`. Les rapports consignent une relecture primaire, sans prétendre à une certification mathématique formelle ou à une revue indépendante.

Le plan et les contrôles sont fournis. Les supports originaux et leurs empreintes sont inclus ; dépôt complet : https://github.com/Lemoine-Cours/analyse/tree/main/analyse-differentielle-convexite
